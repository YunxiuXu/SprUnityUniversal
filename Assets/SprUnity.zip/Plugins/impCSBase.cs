using System;
using System.Runtime.InteropServices;
namespace SprCs {
    public partial class SprExport {
    }
}
