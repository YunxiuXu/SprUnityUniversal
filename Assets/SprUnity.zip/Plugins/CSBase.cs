using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Runtime.InteropServices;
#pragma warning disable 0108
namespace SprCs {
	public partial class IfInfoToCsType {
		public static Dictionary<IntPtr, Type> mapBase = new Dictionary<IntPtr, Type>() {
		};
	}
}
