﻿using UnityEditor;
using UnityEngine;
using System.Collections;

public class RoundConePrimitive : MonoBehaviour {
    // -- Obsolete --
}

